<?php $__env->startSection('title'); ?>  Product details |Pets Zone <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Start -->
    <div class="breadcrumb-area ptb-60 ptb-sm-30">
        <div class="container">
            <div class="breadcrumb">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="shop.html">Shop</a></li>
                    <li class="active"><a href="product.html">Product</a></li>
                </ul>
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Breadcrumb End -->
    <!-- Product Thumbnail Start -->
    <div class="main-product-thumbnail pb-60">
        <div class="container">
            <div class="row">
                <!-- Main Thumbnail Image Start -->
                <div class="col-lg-5">
                    <!-- Thumbnail Large Image start -->
                    <div class="tab-content">
                        <div id="thumb1" class="tab-pane active">
                            <a data-fancybox="images" href="img/products/1.jpg"><img src="img/products/1.jpg" alt="product-view"></a>
                        </div>
                        <div id="thumb2" class="tab-pane">
                            <a data-fancybox="images" href="img/products/2.jpg"><img src="img/products/2.jpg" alt="product-view"></a>
                        </div>
                        <div id="thumb3" class="tab-pane">
                            <a data-fancybox="images" href="img/products/3.jpg"><img src="img/products/3.jpg" alt="product-view"></a>
                        </div>
                        <div id="thumb4" class="tab-pane">
                            <a data-fancybox="images" href="img/products/4.jpg"><img src="img/products/4.jpg" alt="product-view"></a>
                        </div>
                    </div>
                    <!-- Thumbnail Large Image End -->

                    <!-- Thumbnail Image End -->
                    <div class="product-thumbnail">
                        <div class="thumb-menu nav">
                            
                                
                        </div>
                    </div>
                    <!-- Thumbnail image end -->
                </div>
                <!-- Main Thumbnail Image End -->
                <!-- Thumbnail Description Start -->
                <div class="col-lg-7">
                    <div class="thubnail-desc fix">
                        <h3 class="product-header"><?php echo e($product[0]->productlist[0]->text->content); ?></h3>
                        <div class="pro-price mb-10">
                            <p><span class="price"><?php echo e($product[0]->productlist[0]->price->value); ?> ريال</span><del class="prev-price">-32.00</del></p>
                        </div>
                        <div class="pro-ref mb-15">
                            <p><span class="in-stock">IN STOCK</span><span class="sku"><?php echo e($product[0]->instock); ?></span></p>
                        </div>
                        <div class="box-quantity">
                            <form action="#">
                                <input class="number" id="numeric" type="number" min="1" value="1">
                                <a class="add-cart" href="cart.html">add to cart</a>
                            </form>
                        </div>
                        <p class="ptb-20"><?php echo e($product[0]->productlist[1]->text->content); ?></p>
                    </div>
                </div>
                <!-- Thumbnail Description End -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Product Thumbnail End -->
    <!-- Product Thumbnail Description Start -->
    <div class="thumnail-desc pb-60">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="main-thumb-desc nav">
                        <li><a class="active" data-toggle="tab" href="#dtail">Details</a></li>
                    </ul>
                    <!-- Product Thumbnail Tab Content Start -->
                    <div class="tab-content thumb-content border-default">
                        <div id="dtail" class="tab-pane in active">
                            <?php echo e($product[0]->productlist[2]->text->content); ?>

                        </div>
                    </div>
                    <!-- Product Thumbnail Tab Content End -->
                </div>
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Product Thumbnail Description End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AnimalStore\resources\views/website/product_details.blade.php ENDPATH**/ ?>