<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Media;
use App\Models\Price;
use App\Models\Product;
use Illuminate\Database\Seeder;

class MediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Media::insert([
            array(
                'link' => '/img/products/1.jpg',
            ), 
            array(
                'link' => '/img/products/2.jpg',
            ), 
            array(
                'link' => '/img/products/3.jpg',
            ), 
            array(
                'link' => '/img/products/1.jpg',
            ), 
            array(
                'link' => '/img/products/4.jpg',
            ), 
            array(
                'link' => '/img/products/5.jpg',
            ), 
            array(
                'link' => '/img/products/6.jpg',
            ), 
            array(
                'link' => '/img/products/7.jpg',
            ), 
            array(
                'link' => '/img/products/8.jpg',
            ), 
            array(
                'link' => '/img/products/1.jpg',
            ), 
            array(
                'link' => '/img/products/3.jpg',
            ), 
            array(
                'link' => '/img/products/2.jpg',
            ), 
        ]);
    }
}
