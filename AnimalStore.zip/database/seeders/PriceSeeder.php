<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Price;
use App\Models\Product;
use Illuminate\Database\Seeder;

class PriceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Price::insert([
            array(
                'currency_id' => '1',
                'value' => 200,
            ), 
            array(
                'currency_id' => '1',
                'value' => 100,
            ), 
            array(
                'currency_id' => '1',
                'value' => 350,
            ), 
            array(
                'currency_id' => '1',
                'value' => 650,
            ),  
        ]);
    }
}
