<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(LangSeeder::class);
        $this->call(CountrySeeder::class);
        $this->call(CitySeeder::class);
        $this->call(CategorySeeder::class);
        $this->call(AttributeTypeSeeder::class);
        $this->call(AttributeSeeder::class);
        $this->call(CurrencySeeder::class);
        $this->call(ProductSeeder::class);
        $this->call(TextSeeder::class);
        $this->call(PriceSeeder::class);
        $this->call(MediaSeeder::class);
        $this->call(ProductListSeeder::class);
    }
}
