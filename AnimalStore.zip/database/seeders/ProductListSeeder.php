<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Price;
use App\Models\Product;
use App\Models\ProductList;
use Illuminate\Database\Seeder;

class ProductListSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ProductList::insert([
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Text',    //media, text, price, category, attribute
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '3',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Price',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Category',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '1',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '3',
            ),  
            // -----------New Product------------
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Text',    //media, text, price, category, attribute
                'parentable_id'       => '4',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '5',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '6',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Price',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Category',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '9',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '2',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '3',
            ),  
            // -----------New Product------------
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Text',    //media, text, price, category, attribute
                'parentable_id'       => '7',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '8',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '9',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Price',
                'parentable_id'       => '3',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Category',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '2',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '5',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '6',
            ),  
            array(
                'product_id'  => '3',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '7',
            ),  
            // -----------New Product------------
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Text',    //media, text, price, category, attribute
                'parentable_id'       => '10',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '11',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Text',
                'parentable_id'       => '12',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Price',
                'parentable_id'       => '4',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Category',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '1',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Attribute',
                'parentable_id'       => '2',
            ),
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '8',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '9',
            ),  
            array(
                'product_id'  => '4',
                'parentable_type'      => 'App\Models\Media',
                'parentable_id'       => '10',
            ),   
        ]);
    }
}
