<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::insert([
            array(
                'code'  => 'animal 1',
                'label'  => 'Animal 1',
                'url'  => 'animal-1',
                'instock'  => 4,
            ),
            array(
                'code'  => 'animal 2',
                'label'  => 'Animal 2',
                'url'  => 'animal-2',
                'instock'  => 2,
            ),
            array(
                'code'  => 'animal 3',
                'label'  => 'Animal 3',
                'url'  => 'animal-3',
                'instock'  => 5,
            ),
            array(
                'code'  => 'animal 4',
                'label'  => 'Animal 4',
                'url'  => 'animal-4',
                'instock'  => 8,
            ),
            
        ]);
    }
}
