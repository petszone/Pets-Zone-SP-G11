<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Product;
use App\Models\Text;
use Illuminate\Database\Seeder;

class TextSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Text::insert([
            array(
                'type'    => 'name',
                'lang_id' => '1',

                'content' => 'Animal New 1',
            ),
            array(
                'type'    => 'short',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.',
            ),
            array(
                'type'    => 'long',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus ex sequi quia perferendis voluptates consequatur, sint possimus doloremque in.',
            ),
            array(
                'type'    => 'name',
                'lang_id' => '1',

                'content' => 'Animal New 1',
            ),
            array(
                'type'    => 'short',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.',
            ),
            array(
                'type'    => 'long',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus ex sequi quia perferendis voluptates consequatur, sint possimus doloremque in.',
            ),
            array(
                'type'    => 'name',
                'lang_id' => '1',

                'content' => 'Animal New 1',
            ),
            array(
                'type'    => 'short',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.',
            ),
            array(
                'type'    => 'long',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus ex sequi quia perferendis voluptates consequatur, sint possimus doloremque in.',
            ),
            array(
                'type'    => 'name',
                'lang_id' => '1',

                'content' => 'Animal New 1',
            ),
            array(
                'type'    => 'short',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.',
            ),
            array(
                'type'    => 'long',
                'lang_id' => '1',

                'content' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus ex sequi quia perferendis voluptates consequatur, sint possimus doloremque in.',
            ),
        ]);
    }
}
