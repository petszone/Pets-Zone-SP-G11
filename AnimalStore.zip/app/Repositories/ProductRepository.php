<?php

namespace App\Repositories;

use App\Interfaces\ProductRepositoryInterface;
use App\Models\Attribute;
use App\Models\Media;
use App\Models\Price;
use App\Models\Product;
use App\Models\ProductList;
use App\Models\Text;
use App\Traits\SaveImageTrait;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\DB;

class ProductRepository implements ProductRepositoryInterface
{
    use SaveImageTrait;
    
    protected $domains = ['productlist.text', 'productlist.price', 'productlist.attribute', 'productlist.media', 'productlist.category'];
    

    public function getAllProducts()
    {
        return Product::with($this->domains)->get();
    }

    public function getProductById($productId, array $lists)
    {
        if($lists[0] == '*'){
            $product = Product::where('id', $productId)->with($this->domains)->first();
        }else{
            $product = Product::where('id', $productId)->with($lists)->first();
        }
        dd($product);
        return $product;
    }

    public function createProduct(array $productDetails)
    {
        DB::transaction(function () use($productDetails) {
            $product = Product::create([
                'label'  => $productDetails['name'],
            ]);
            $this->addPrice($productDetails, $product);
            $this->addMedia($productDetails, $product);
            $this->addText($productDetails, $product);
        });
        return 'success';
    }
 
    public function addPrice($productDetails, $product)
    {
        $price = Price::create([
            'currency_id'  => 1,
            'value'  => $productDetails['price'],
        ]);
        $this->addProductList($price, $product, 'Price');

        return 'success';
    }

    public function addMedia($productDetails, $product)
    {
        foreach($productDetails['images'] as $product_image)
        {
            $media = Media::create([
                'domain'  => 'product',
                'link'  => $this->uploadImage($product_image, 'products'),
            ]);
            $this->addProductList($media, $product, 'Media');
        }
        return 'success';
    }

    public function addText($productDetails, $product)
    {
        foreach($productDetails['text'] as $product_text)
        {
            $text = Text::create([
                'type'  => $product_text['type'],
                'lang_id'  => 1,
                'content'  => $product_text['content'],
            ]);
            $this->addProductList($text, $product, 'Text');
        }
        return 'success';
    }

    public function addProductList($domainList, $product, $parentable_type)
    {
        ProductList::create([
            'product_id'        => $product->id,
            'parentable_type'   => 'App\Models\/' . $parentable_type,
            'parentable_id'     => $domainList->id,  
        ]);
    }

    public function updateProduct($productId, array $newDetails)
    {
        $product = Product::findOrFail($productId);
        $priceId = ProductList::where('parentable_type', 'App\Models\Price')->where('product_id', $product->id)->first()->parentable_id;
        // $mediasIds = Media::where('parentable_type', 'App\Models\Media')->where('product_id', $product->id)->pluck('parentable_id');
        // $textsIds = ProductList::where('parentable_type', 'App\Models\Text')->where('product_id', $product->id)->pluck('parentable_id');
        DB::transaction(function () use($newDetails, $product, $priceId) {
            $product->update([
                'label' => $newDetails['name'], 
                'instock'  => $newDetails['instock'], 
                'status'   => $newDetails['status'],
            ]);
            $this->updatePrice($newDetails, $priceId);
            $this->updateMedia($newDetails['images']);
            $this->updateText($newDetails['text']);
        });
        return $product;
    }

    public function updatePrice($newDetails, $priceId)
    {
        $price = Price::whereId($priceId)->update([
            'currency_id'  => 1,
            'value'  => $newDetails['price'],
        ]);
        return 'success';
    }
    
    
    public function updateMedia($newDetails)
    {
        foreach($newDetails as $key=>$value)
        {
            Media::whereId($key)->update([
                'link'  => $this->uploadImage($value, 'products'),
            ]);
        }
        return 'success';
    }

    public function updateText($newDetails)
    {
        foreach($newDetails as $key=>$value)
        {
            Text::whereId($key)->update([
                'content'  => $value,
            ]);
        }
        return 'success';
    }


    public function deleteProduct($productId)
    {
        DB::transaction(function () use($productId) {
            $product_list = ProductList::where('product_id', $productId)->get();
            Product::destroy($productId);
            Price::whereIn('id',$product_list->where('parentable_type', 'App\Models\Price')->pluck('parentable_id'))->delete();
            Media::whereIn('id',$product_list->where('parentable_type', 'App\Models\Media')->pluck('parentable_id'))->delete();
            Text::whereIn('id',$product_list->where('parentable_type', 'App\Models\Text')->pluck('parentable_id'))->delete();
            foreach($product_list as $item)
            {
                ProductList::destroy($item->id);
            }
        });

        return 'success';
    }
}
