<?php

namespace App\Http\Requests\Product;

use Illuminate\Foundation\Http\FormRequest;

class CreateProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    // public function authorize()
    // {
        // return false;
    // }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'              => 'required|string|max:255',
            'price'             => 'required|numeric',
            // 'text.0.type'       => 'required|string|in:name',
            // 'text.0.content'    => 'required|string|max:255',
            // 'text.1.type'       => 'required|string|in:short',
            // 'text.1.content'    => 'required|string|max:500',
            // 'text.2.type'       => 'required|string|in:long',
            // 'text.2.content'    => 'required|string',
            'images.*'          => 'required|file|image|mimes:jpeg,png,jpg,gif',
        ];
    }

    public function messages()
    {
        return [
            'text.0.type.required'      => 'ادخل اسم المنتج',
            'text.0.content.required'   => 'ادخل اسم المنتج',
            'text.1.type.required'      => 'ادخل وصف قصير للمنتج',
            'text.1.content.required'   => 'ادخل وصف قصير للمنتج',
            'text.2.type.required'      => 'ادخل وصف طويل للمنتج',
            'text.2.content.required'   => 'ادخل وصف طويل للمنتج',
        ];
    }
}
