<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\CreateProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Interfaces\ProductRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class ProductController extends Controller
{
    private ProductRepositoryInterface $productRepository;

    public function __construct(ProductRepositoryInterface $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public function index()
    {
        return response()->json([
            'data' => $this->productRepository->getAllProducts()
        ]);
    }

    public function create()
    {
        //
    }

    public function store(CreateProductRequest $request, $id = null)
    {
        if(request()->routeIs('product.store')){
            $data = $request->except('_token');
            dd($this->productRepository->createProduct($data));
        }elseif(request()->routeIs('product.update')){
            $data = $request->except('_token');
            dd($this->productRepository->updateProduct($id, $data));
        }



    }

    public function show($id)
    {
        dd($this->productRepository->getProductById($id, array('*')));
    }

    public function edit($id)
    {
        dd($this->productRepository->getProductById($id, array('*')));
    }

    public function update(UpdateProductRequest $request, $id)
    {

    }

    public function destroy($id)
    {
        dd($this->productRepository->deleteProduct($id));
    }
}