<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Text extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'texts';
    protected $fillable = [
        'type',     //name, long desc, short desc
        'lang_id',
        'content',
        'status',   //default 1
    ];
 
    public function productlist()
    {
        return $this->morphMany(ProductList::class, 'parentable');
    }
}
