<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'addresses';
    protected $fillable = [
        'user_id',
        'firstname',
        'lastname',
        'address1',
        'address2',
        'postal',
        'city_id',
        'country_id',
        'lang_id',
        'telephone',
        'email',
        'default',      //boolean
        'pos',          //position null
    ];

 
}
