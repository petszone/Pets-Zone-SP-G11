<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OrderAddress extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'order_addresses';
    protected $fillable = [
        'user_id',
        'order_id',
        'address_id',
        'firstname',
        'lastname',
        'address1',
        'address2',
        'postal',
        'city_id',
        'country_id',
        'lang_id',
        'telephone',
        'email',
        'pos',    //position null
    ];
}
