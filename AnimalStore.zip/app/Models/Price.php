<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Price extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'prices';
    protected $fillable = [
        'label',        //name null
        'currency_id',
        'value',
        'rebate',
        'taxrate',
        'status',       //default 1
    ];

    public function productlist()
    {
        return $this->morphMany(ProductList::class, 'parentable');
    }
}
