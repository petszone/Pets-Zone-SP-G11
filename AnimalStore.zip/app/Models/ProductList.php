<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductList extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'product_lists';
    protected $fillable = [
        'product_id',
        // 'domain',   //media, text, price, category, attribute                      //old
        // 'refid',    //media_id, text_id, price_id, category_id, attribute_id       //old
        'parentable_type',   //media, text, price, category, attribute
        'parentable_id',    //media_id, text_id, price_id, category_id, attribute_id
        'pos',      //position null
        'status',   //default 1
    ];

    public function parentable()
    {
        return $this->morphTo();
    }
     
    public function text()
    {
        return $this->belongsTo(Text::class, 'parentable_id');
    }

    public function price()
    {
        return $this->belongsTo(Price::class, 'parentable_id');
    }

    public function attribute()
    {
        return $this->belongsTo(Attribute::class, 'parentable_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class, 'parentable_id');
    }

    public function media()
    {
        return $this->belongsTo(Media::class, 'parentable_id');
    }
}
