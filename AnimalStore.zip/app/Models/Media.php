<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Media extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'media';
    protected $fillable = [
        'domain',   //product, attribute
        'label',    //image name
        'link',     //image link
        'preview',  //(null) for multi width sizes purpose 
        'status',   //default 1
    ];

    public function productlist()
    {
        return $this->morphMany(ProductList::class, 'parentable');
    }
}
